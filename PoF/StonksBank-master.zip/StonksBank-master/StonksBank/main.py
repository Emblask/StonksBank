from view.console import ejecutar

ejecutar()